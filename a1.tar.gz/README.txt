when prompted enter a cipher key that you wish to use to encrypt your message
the message must be in a file, try and use only text otherwise things start to get weird
run a test with the test.txt file included to see an example of how the ciper works